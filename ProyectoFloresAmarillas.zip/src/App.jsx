import React from 'react'
import FloresAmarillas from './FloresAmarillas.jsx'

export default function App() {
  return (
    <FloresAmarillas />
  )
}