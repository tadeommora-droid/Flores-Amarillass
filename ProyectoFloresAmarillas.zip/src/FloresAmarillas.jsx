import React, { useRef, useState, useEffect } from "react";

export default function FloresAmarillas() {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    return () => {
      if (audioRef.current) audioRef.current.pause();
    };
  }, []);

  const togglePlay = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      a.play();
      setPlaying(true);
    } else {
      a.pause();
      setPlaying(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-yellow-50 via-yellow-100 to-amber-50 p-6">
      <div className="max-w-3xl w-full bg-white/80 backdrop-blur-lg rounded-2xl shadow-2xl p-8 md:p-12 border border-yellow-200">
        <div className="flex items-center gap-4">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-yellow-300 to-amber-400 flex items-center justify-center shadow-xl flower">
            🌻
          </div>

          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight text-amber-800">Flores Amarillas</h1>
            <p className="mt-1 text-sm md:text-base text-amber-700/80">Tarjeta musical bonita.</p>

            <div className="mt-4 flex items-center gap-3">
              <button onClick={togglePlay} className="px-4 py-2 rounded-full bg-amber-500 hover:bg-amber-600 text-white font-semibold shadow-lg">
                {playing ? 'Pausa' : 'Reproducir'}
              </button>
              <button onClick={() => { if (audioRef.current) { audioRef.current.currentTime = 0; audioRef.current.play(); setPlaying(true); } }} className="px-3 py-2 rounded-full border border-amber-300 text-amber-700/90 bg-white/60">
                Reiniciar
              </button>
            </div>
          </div>
        </div>

        <audio ref={audioRef} src="/ruta-a-tu-cancion.mp3" preload="none" />
      </div>
    </div>
  );
}